package com.Redbus.redbus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedbusApplicationTests {

	@Test
	void contextLoads() {
	}

}
