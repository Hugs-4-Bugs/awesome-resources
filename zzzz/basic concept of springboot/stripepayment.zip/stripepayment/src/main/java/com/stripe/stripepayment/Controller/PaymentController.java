package com.stripe.stripepayment.Controller;

import com.stripe.stripepayment.Service.OrderService;
import com.stripe.stripepayment.entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Value("${stripe.apiKey}")
    private String stripeApiKey;

    private final OrderService orderService;

    @Autowired
    public PaymentController(OrderService orderService) {
        this.orderService = orderService;
    }
    //http://localhost:8080/payments
    // Endpoint for creating a payment and saving the order
    @PostMapping
    public ResponseEntity<String> makePayment(@RequestBody Order order) {
        try {
            Stripe.apiKey = stripeApiKey;

            PaymentIntentCreateParams createParams = new PaymentIntentCreateParams.Builder()
                    .setCurrency("usd")
                    .setAmount(order.getAmount())
                    .setDescription(order.getDescription())
                    .build();

            PaymentIntent paymentIntent = PaymentIntent.create(createParams);


            orderService.saveOrder(order); // Save the order to the database

            return ResponseEntity.ok(paymentIntent.getClientSecret());
        } catch (StripeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}
