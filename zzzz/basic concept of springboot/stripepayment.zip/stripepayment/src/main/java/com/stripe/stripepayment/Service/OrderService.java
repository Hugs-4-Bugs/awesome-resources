package com.stripe.stripepayment.Service;

import com.stripe.stripepayment.entity.Order;

public interface OrderService {
    Order saveOrder(Order order);
}
