package com.stripe.stripepayment.Controller;


import com.stripe.stripepayment.Dto.OrderDTO;
import com.stripe.stripepayment.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Value("${stripe.apiKey}") // accesing the API key
    private String stripeApiKey;

    private final OrderService orderService;

    @Autowired
    public PaymentController(OrderService orderService) {
        this.orderService = orderService;
    }

    // Endpoint for creating a payment and saving the order
    @PostMapping
    public ResponseEntity<String> makePayment(@RequestBody OrderDTO orderDTO) {
        try {
            // Initialize Stripe with the API key
            Stripe.apiKey = stripeApiKey;

            // Set payment parameters based on OrderDTO
            PaymentIntentCreateParams createParams = new PaymentIntentCreateParams.Builder()
                    .setCurrency("usd")
                    .setAmount(orderDTO.getAmount())
                    .setDescription(orderDTO.getDescription())
                    .build();

            // Create the payment intent with Stripe
            PaymentIntent paymentIntent = PaymentIntent.create(createParams);

            // Save the order to the database
            orderService.saveOrder(orderDTO);

            // Return the client secret for the created payment intent
            return ResponseEntity.ok(paymentIntent.getClientSecret());
        } catch (StripeException e) {
            // Handle Stripe errors and respond with an error message
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}
